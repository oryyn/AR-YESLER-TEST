AR YESLER DEV TEST

#Overall Notes
- Took the weekend spare time to work on this layout.  Thought regardless of three business days or three days total, this would be a good time to turn in given my timeline.

#Development Notes

- Used bootstrap-based template
- template contains technologies not utilized in "final" dev site
- same with CSS (utilizing some styles not being used)
-Wrote JS code to display NEW Json file (just added a title to original) which displays six random images, with meta data, non-repeating - resizes on mobile  (one col, not two)
- Added and included errors and hover states for form
- Uses some combinations of manual, modern, and flex-based css
- Text sizes and font-families might be slightly off as no guide specifically was provided, so had to guestimate on what would be used instead.
- Tested on IDE Live server locally, for mobile and desktop - in Chrome and Edge (IE)


# To-Do upon first review (if this were a real-life project)
- review with other developers
- adjust CSS to directly match mockup
- get additional mockup styles