# AR YESLER DEV TEST

### OVERALL NOTES

  - Took the weekend spare time to work on this layout.  Thought regardless of three business days or three days total, this would be a good time to turn in given my timeline.

### Development Notes

Install the dependencies and devDependencies and start the server.

```sh
- Used bootstrap-based template
- Template contains technologies not utilized in "final" dev site
- Same with CSS (utilizing some styles not being used)
- Wrote JS code to display NEW Json file (just added a title to original) which displays six random images, with meta data, = - Non-repeating - resizes on mobile  (one col, not two)
- Added and included errors and hover states for form
- Uses some combinations of manual, modern, and flex-based css
- Text sizes and font-families might be slightly off as no guide specifically was provided, so had to guestimate on what would be used instead.

```

### To-Do upon first review (if this were a real-life project)

  - review with other developers
- adjust CSS to directly match mockup
- get additional mockup styles